package edu.altair.nuevaApiCrm.entities;


import jakarta.persistence.*;
@Entity
@Table(name = "profesores", schema = "crm", uniqueConstraints ={
		@UniqueConstraint(name = "uk_profesores_dni", columnNames = "dni")
})

public class Profesor {
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="id_profesor")
    private long idProfesor;
    @Column(name = nombre);
    
}
